﻿using StreamingForAll;
using System.Threading.Tasks.Dataflow;
namespace StreamingForAll
{
    public class FileReadBlock<T>
    {
        public string path;
        public Action<T> DataArrived;
        public FileReadBlock(string path)
        {
            this.path = path;
        }
        public void Start()
        {
            int r;
            string s;
            if (typeof(T) == typeof(char))
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    while ((r = sr.Read()) != -1)
                    {
                        DataArrived((T)Convert.ChangeType(r, typeof(T)));
                    }
                }
            }
            else if (typeof(T) == typeof(byte))
            {
                using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read))
                {
                    while ((r = fs.ReadByte()) != -1)
                    {
                        DataArrived((T)Convert.ChangeType(r, typeof(T)));
                    }

                }
            }
            else if (typeof(T) == typeof(string))
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    while ((s = sr.ReadLine()) != null)
                    {
                        DataArrived((T)Convert.ChangeType(s, typeof(T)));
                    }
                }
            }
        }
    }

    public class FileWriteBlock<T>
    {
        public ActionBlock<T> InputBlock;
        public FileWriteBlock(string path)
        {
            InputBlock = new ActionBlock<T>(p =>
            {
                using (StreamWriter sw = new StreamWriter(path))
                {
                    sw.Write(p);
                    Console.Write(p);
                }
            });
        }
        public void Enqueue(T input)
        {
            InputBlock.Post(input);
        }
    }

    public class ConsoleWriteBlock<T>
    {
        public ActionBlock<T> InputBlock;
        public ConsoleWriteBlock()
        {
            InputBlock = new ActionBlock<T>(p =>
            {
                Console.Write(p);
            });
        }
    }

    public class FileReadStringBlock
    {
        public string path;
        public Action<string> DataArrived;
        public FileReadStringBlock(string path)
        {
            this.path = path;
        }
        public void Start()
        {
            int r;
            string s;
            using (StreamReader sr = new StreamReader(path))
            {
                while ((s = sr.ReadLine()) != null)
                {
                    DataArrived(s);
                }
            }
        }
    }

    public class FileWriteStringBlock
    {
        public ActionBlock<string> InputBlock;
        public FileWriteStringBlock(string path)
        {
            InputBlock = new ActionBlock<string>(p =>
            {
                //用StreaWriter有问题的部分
                //using (StreamWriter sw = new StreamWriter(path))
                //{
                //    sw.Write(p);
                //    Console.Write(p);
                //}
                File.AppendAllText(path, p);
            });
        }
        public void Enqueue(string input)
        {
            InputBlock.Post(input);
        }
    }

    class useless
    {
        static void Main()
        {
            FileReadStringBlock FRB = new FileReadStringBlock("C:\\Users\\DELL\\桌面\\zdg学习\\c#LearningForZdg\\Test1.txt");
            FileWriteStringBlock FWB = new FileWriteStringBlock("C:\\Users\\DELL\\桌面\\zdg学习\\c#LearningForZdg\\TextToText.txt");
            FRB.DataArrived += (e) =>
            {
                FWB.Enqueue(e);
            };
            FRB.Start();
            Console.ReadKey();
        }
    }
}

